module("luci.controller.admin.upgrade",package.seeall)
function index()
local e=nixio.fs.access("/lib/upgrade/platform.sh")
if e then
entry({"admin","upgrade"},call("action_upgrade"),_("Upgrade firmware"),90)
entry({"admin","upgrade","reboot"},template("admin/upgrade_reboot"),nil,nil)
end
end
function action_upgrade()
local e="/tmp/firmware.img"
local t
luci.http.setfilehandler(
function(i,a,o)
if not nixio.fs.access(e)and not t and a and#a>0 then
t=io.open(e,"w")
end
if t and a then
t:write(a)
end
if t and o then
t:close()
end
end
)
local t=tonumber(luci.http.formvalue("step")or 1)
local a=nixio.fs.access(e)
local o=image_supported(e)
if not a or not o or t==1 then
if a then
nixio.fs.unlink(e)
end
luci.template.render("admin/upgrade",{
bad_image=(a and not o or false)
})
elseif t==2 then
luci.template.render("admin/upgrade_confirm",{
checksum=image_checksum(e),
filesize=nixio.fs.stat(e).size,
flashsize=storage_size(),
keepconfig=luci.http.formvalue("keepcfg")=="1"
})
elseif t==3 then
local t=luci.http.formvalue("keepcfg")=="1"
fork_exec("/sbin/sysupgrade %s %q"%{t and""or"-n",e})
luci.http.redirect(luci.dispatcher.build_url("admin","upgrade","reboot"))
end
end
function fork_exec(t)
local e=nixio.fork()
if e>0 then
return
elseif e==0 then
nixio.chdir("/")
local e=nixio.open("/dev/null","w+")
if e then
nixio.dup(e,nixio.stderr)
nixio.dup(e,nixio.stdout)
nixio.dup(e,nixio.stdin)
if e:fileno()>2 then
e:close()
end
end
nixio.exec("/bin/sh","-c",t)
end
end
function image_supported(e)
return(0==os.execute(
"/sbin/sysupgrade -T %q >/dev/null"
%e
))
end
function storage_size()
local e=0
if nixio.fs.access("/proc/mtd")then
for t in io.lines("/proc/mtd")do
local o,a,o,t=t:match('^([^%s]+)%s+([^%s]+)%s+([^%s]+)%s+"([^%s]+)"')
if t=="linux"then
e=tonumber(a,16)
break
end
end
elseif nixio.fs.access("/proc/partitions")then
for t in io.lines("/proc/partitions")do
local o,o,a,t=t:match('^%s*(%d+)%s+(%d+)%s+([^%s]+)%s+([^%s]+)')
if a and t and not t:match('[0-9]')then
e=tonumber(a)*1024
break
end
end
end
return e
end
function image_checksum(e)
return(luci.sys.exec("md5sum %q"%e):match("^([^%s]+)"))
end
