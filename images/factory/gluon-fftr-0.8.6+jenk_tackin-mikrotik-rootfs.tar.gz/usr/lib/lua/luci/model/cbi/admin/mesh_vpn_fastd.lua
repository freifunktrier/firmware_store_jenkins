local e=luci.model.uci.cursor()
local i=luci.util
local t=SimpleForm('mesh_vpn',translate('Mesh VPN'))
t.template="admin/expertmode"
local a=t:section(SimpleSection)
local a=a:option(Value,'mode')
a.template="gluon/cbi/mesh-vpn-fastd-mode"
local o=e:get('fastd','mesh_vpn','method')
if i.contains(o,'null')then
a.default='performance'
else
a.default='security'
end
function t.handle(a,t,o)
if t==FORM_VALID then
local a=require'gluon.site_config'
local t={}
if o.mode=='performance'then
table.insert(t,'null')
end
for o,a in ipairs(a.fastd_mesh_vpn.methods)do
if a~='null'then
table.insert(t,a)
end
end
e:set('fastd','mesh_vpn','method',t)
e:save('fastd')
e:commit('fastd')
end
end
return t
