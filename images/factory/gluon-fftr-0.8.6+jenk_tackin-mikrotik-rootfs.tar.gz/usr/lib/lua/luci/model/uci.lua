local i=require"os"
local e=require"uci"
local u=require"luci.util"
local d=require"table"
local t,t,t=setmetatable,rawget,rawset
local t,o=require,getmetatable
local a,h,t,c=error,pairs,ipairs,next
local a,s,r,n=type,tostring,tonumber,unpack
module"luci.model.uci"
cursor=e.cursor
APIVERSION=e.APIVERSION
function cursor_state()
return cursor(nil,"/var/state")
end
inst=cursor()
inst_state=cursor_state()
local e=o(inst)
function e.apply(a,e,t)
e=a:_affected(e)
if t then
return{"/sbin/luci-reload",n(e)}
else
return i.execute("/sbin/luci-reload %s >/dev/null 2>&1"
%d.concat(e," "))
end
end
function e.delete_all(i,n,s,e)
local o={}
if a(e)=="table"then
local t=e
e=function(a)
for e,t in h(t)do
if a[e]~=t then
return false
end
end
return true
end
end
local function a(t)
if not e or e(t)then
o[#o+1]=t[".name"]
end
end
i:foreach(n,s,a)
for t,e in t(o)do
i:delete(n,e)
end
end
function e.section(o,a,i,e,n)
local t=true
if e then
t=o:set(a,e,i)
else
e=o:add(a,i)
t=e and true
end
if t and n then
t=o:tset(a,e,n)
end
return t and e
end
function e.tset(i,o,a,t)
local e=true
for t,n in h(t)do
if t:sub(1,1)~="."then
e=e and i:set(o,a,t,n)
end
end
return e
end
function e.get_bool(e,...)
local e=e:get(...)
return(e=="1"or e=="true"or e=="yes"or e=="on")
end
function e.get_list(i,o,e,t)
if o and e and t then
local e=i:get(o,e,t)
return(a(e)=="table"and e or{e})
end
return nil
end
function e.get_first(s,i,n,e,t)
local o=t
s:foreach(i,n,
function(i)
local e=not e and i['.name']or i[e]
if a(t)=="number"then
e=r(e)
elseif a(t)=="boolean"then
e=(e=="1"or e=="true"or
e=="yes"or e=="on")
end
if e~=nil then
o=e
return false
end
end)
return o
end
function e.set_list(n,i,o,t,e)
if i and o and t then
return n:set(
i,o,t,
(a(e)=="table"and e or{e})
)
end
return false
end
function e.add_to_set(o,s,i,n,r,l)
local e=o:get_list(s,i,n)
if not e then
return false
end
local a={}
for t,e in t(e)do
a[e]=true
end
if l then
a[r]=nil
else
a[r]=true
end
e={}
for t,a in h(a)do
d.insert(e,t)
end
if c(e)==nil then
return o:delete(s,i,n)
else
return o:set(s,i,n,e)
end
end
function e.remove_from_set(t,e,i,o,a)
t:add_to_set(e,i,o,a,true)
end
function e._affected(o,e)
e=a(e)=="table"and e or{e}
local n=cursor()
n:load("ucitrack")
local a={}
local function o(i)
local a={i}
local e={}
n:foreach("ucitrack",i,
function(a)
if a.affects then
for a,t in t(a.affects)do
e[#e+1]=t
end
end
end)
for i,e in t(e)do
for t,e in t(o(e))do
a[#a+1]=e
end
end
return a
end
for i,e in t(e)do
for t,e in t(o(e))do
if not u.contains(a,e)then
a[#a+1]=e
end
end
end
return a
end
function e.substate(t)
e._substates=e._substates or{}
e._substates[t]=e._substates[t]or cursor_state()
return e._substates[t]
end
local a=e.load
function e.load(t,...)
if e._substates and e._substates[t]then
a(e._substates[t],...)
end
return a(t,...)
end
local a=e.unload
function e.unload(t,...)
if e._substates and e._substates[t]then
a(e._substates[t],...)
end
return a(t,...)
end
