local o=require"luci.cbi"
local a=require"luci.i18n"
local t=luci.model.uci.cursor()
local e=require'gluon.site_config'
local n={}
local function s()
if((e.config_mode or{}).geo_location or{}).show_altitude~=false then
return true
end
if t:get_first("gluon-node-info","location","altitude")then
return true
end
return false
end
function n.section(i)
local e=a.translate('If you want the location of your node to '
..'be displayed on the map, you can enter its coordinates here.')
if s()then
e=e..' '..a.translate('Specifying the altitude is '
..'optional and should only be done if a proper value is known.')
end
local i=i:section(o.SimpleSection,nil,e)
local e
e=i:option(o.Flag,"_location",a.translate("Show node on the map"))
e.default=t:get_first("gluon-node-info","location","share_location",e.disabled)
e.rmempty=false
e=i:option(o.Value,"_latitude",a.translate("Latitude"))
e.default=t:get_first("gluon-node-info","location","latitude")
e:depends("_location","1")
e.rmempty=false
e.datatype="float"
e.description=a.translatef("e.g. %s","53.873621")
e=i:option(o.Value,"_longitude",a.translate("Longitude"))
e.default=t:get_first("gluon-node-info","location","longitude")
e:depends("_location","1")
e.rmempty=false
e.datatype="float"
e.description=a.translatef("e.g. %s","10.689901")
if s()then
e=i:option(o.Value,"_altitude",a.translate("Altitude"))
e.default=t:get_first("gluon-node-info","location","altitude")
e:depends("_location","1")
e.rmempty=true
e.datatype="float"
e.description=a.translatef("e.g. %s","11.51")
end
end
function n.handle(e)
local a=t:get_first("gluon-node-info","location")
t:set("gluon-node-info",a,"share_location",e._location)
if e._location and e._latitude~=nil and e._longitude~=nil then
t:set("gluon-node-info",a,"latitude",e._latitude:trim())
t:set("gluon-node-info",a,"longitude",e._longitude:trim())
if e._altitude~=nil then
t:set("gluon-node-info",a,"altitude",e._altitude:trim())
else
t:delete("gluon-node-info",a,"altitude")
end
end
t:save("gluon-node-info")
t:commit("gluon-node-info")
end
return n
