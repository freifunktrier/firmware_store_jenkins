local e='/lib/gluon/core/sysconfig/'
local function i(a,t)
local e=io.open(e..t)
if e then
local t=e:read('*line')
e:close()
return(t or'')
end
return nil
end
local function o(o,t,a)
if a then
local e=io.open(e..t,'w+')
e:write(a)
e:close()
else
os.remove(e..t)
end
end
local e=setmetatable
module'gluon.sysconfig'
e(_M,
{
__index=i,
__newindex=o,
}
)
return _M
