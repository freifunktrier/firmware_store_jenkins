local a=require"luci.cbi"
local o=require"luci.i18n"
local t=luci.model.uci.cursor()
local n={}
function n.section(i)
local e=o.translate('Your internet connection can be used to establish an '..
'encrypted connection with other nodes. '..
'Enable this option if there are no other nodes reachable '..
'over WLAN in your vicinity or you want to make a part of '..
'your connection\'s bandwidth available for the network. You can limit how '..
'much bandwidth the node will use at most.')
local i=i:section(a.SimpleSection,nil,e)
local e
e=i:option(a.Flag,"_meshvpn",o.translate("Use internet connection (mesh VPN)"))
e.default=t:get_bool("fastd","mesh_vpn","enabled")and e.enabled or e.disabled
e.rmempty=false
e=i:option(a.Flag,"_limit_enabled",o.translate("Limit bandwidth"))
e:depends("_meshvpn","1")
e.default=t:get_bool("simple-tc","mesh_vpn","enabled")and e.enabled or e.disabled
e.rmempty=false
e=i:option(a.Value,"_limit_ingress",o.translate("Downstream (kbit/s)"))
e:depends("_limit_enabled","1")
e.value=t:get("simple-tc","mesh_vpn","limit_ingress")
e.rmempty=false
e.datatype="uinteger"
e=i:option(a.Value,"_limit_egress",o.translate("Upstream (kbit/s)"))
e:depends("_limit_enabled","1")
e.value=t:get("simple-tc","mesh_vpn","limit_egress")
e.rmempty=false
e.datatype="uinteger"
end
function n.handle(e)
t:set("fastd","mesh_vpn","enabled",e._meshvpn)
t:save("fastd")
t:commit("fastd")
if e._limit_enabled~=nil then
t:set("simple-tc","mesh_vpn","interface")
t:set("simple-tc","mesh_vpn","enabled",e._limit_enabled)
t:set("simple-tc","mesh_vpn","ifname","mesh-vpn")
if e._limit_ingress~=nil then
t:set("simple-tc","mesh_vpn","limit_ingress",e._limit_ingress:trim())
end
if e._limit_egress~=nil then
t:set("simple-tc","mesh_vpn","limit_egress",e._limit_egress:trim())
end
t:save("simple-tc")
t:commit("simple-tc")
end
end
return n
