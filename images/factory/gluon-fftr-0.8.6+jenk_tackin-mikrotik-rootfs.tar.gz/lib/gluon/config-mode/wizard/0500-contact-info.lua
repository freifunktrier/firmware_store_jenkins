local t=require"luci.cbi"
local a=require"luci.i18n"
local e=luci.model.uci.cursor()
local i=require'gluon.site_config'
local o={}
function o.section(o)
local o=o:section(t.SimpleSection,nil,a.translate(
'Please provide your contact information here to '
..'allow others to contact you. Note that '
..'this information will be visible <em>publicly</em> '
..'on the internet together with your node\'s coordinates.'
)
)
local t=o:option(t.Value,"_contact",a.translate("Contact info"))
t.default=e:get_first("gluon-node-info","owner","contact","")
t.rmempty=not((i.config_mode or{}).owner or{}).obligatory
t.datatype="string"
t.description=a.translate("e.g. E-mail or phone number")
t.maxlen=140
end
function o.handle(t)
if t._contact~=nil then
e:set("gluon-node-info",e:get_first("gluon-node-info","owner"),"contact",t._contact)
else
e:delete("gluon-node-info",e:get_first("gluon-node-info","owner"),"contact")
end
e:save("gluon-node-info")
e:commit("gluon-node-info")
end
return o
