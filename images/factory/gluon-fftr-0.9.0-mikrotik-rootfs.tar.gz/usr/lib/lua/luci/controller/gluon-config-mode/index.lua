module("luci.controller.gluon-config-mode.index",package.seeall)
function index()
local e=luci.model.uci.cursor_state()
if e:get_first("gluon-setup-mode","setup_mode","running","0")=="1"then
local e=node()
if not e.target then
e.target=alias("gluon-config-mode")
e.index=true
end
page=node()
page.lock=true
page.target=alias("gluon-config-mode")
page.subindex=true
page.index=false
page=node("gluon-config-mode")
page.title=_("Wizard")
page.target=alias("gluon-config-mode","wizard")
page.order=5
page.setuser="root"
page.setgroup="root"
page.index=true
entry({"gluon-config-mode","wizard"},form("gluon-config-mode/wizard")).index=true
entry({"gluon-config-mode","reboot"},call("action_reboot"))
end
end
function action_reboot()
local e=luci.model.uci.cursor()
e:set("gluon-setup-mode",e:get_first("gluon-setup-mode","setup_mode"),"configured","1")
e:save("gluon-setup-mode")
e:commit("gluon-setup-mode")
local o=require"gluon.luci"
local a=require"nixio.fs"
local t=require"nixio.util"
local n=require"pretty_hostname"
local i="/lib/gluon/config-mode/reboot/"
local t=t.consume(a.dir(i))
table.sort(t)
local a={}
for t,e in ipairs(t)do
if e:sub(1,1)~='.'then
local e=dofile(i..'/'..e)
if e~=nil then
table.insert(a,e)
end
end
end
local e=n.get(e)
luci.template.render("gluon/config-mode/reboot",
{
parts=a,
hostname=e,
escape=o.escape,
urlescape=o.urlescape,
}
)
if nixio.fork()==0 then
nixio.dup(nixio.open('/dev/null','w'),nixio.stdout)
nixio.nanosleep(1)
nixio.execp("reboot")
end
end
