local e=require'luci.i18n'
return function()luci.template.render_string(e.translate('gluon-config-mode:reboot'))end
