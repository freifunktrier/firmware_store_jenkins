local o=require"nixio.fs"
local a=Map("system",translate("SSH keys"))
a.pageaction=false
a.template="admin/expertmode"
if o.access("/etc/config/dropbear")then
local t=a:section(TypedSection,"_dummy1",nil,
translate("You can provide your SSH keys here (one per line):"))
t.addremove=false
t.anonymous=true
function t.cfgsections()
return{"_keys"}
end
local e
e=t:option(TextValue,"_data","")
e.wrap="off"
e.rows=5
e.rmempty=true
function e.cfgvalue()
return o.readfile("/etc/dropbear/authorized_keys")or""
end
function e.write(t,t,e)
if e then
o.writefile("/etc/dropbear/authorized_keys",e:gsub("\r\n","\n"):trim().."\n")
end
end
function e.remove(t,t)
if e:formvalue("_keys")then
o.remove("/etc/dropbear/authorized_keys")
end
end
end
local e=Map("system",translate("Password"))
e.reset=false
e.pageaction=false
e.template="admin/expertmode"
local t=e:section(TypedSection,"_dummy2",nil,translate(
"Alternatively, you can set a password to access you node. Please choose a secure password you don't use anywhere else.<br /><br />"
.."If you set an empty password, login via password will be disabled. This is the default."))
t.addremove=false
t.anonymous=true
local i=t:option(Value,"pw1",translate("Password"))
i.password=true
local o=t:option(Value,"pw2",translate("Confirmation"))
o.password=true
function t.cfgsections()
return{"_pass"}
end
function e.on_commit(t)
local t=i:formvalue("_pass")
local a=o:formvalue("_pass")
if t and a then
if t==a then
if#t>0 then
if luci.sys.user.setpasswd('root',t)==0 then
e.message=translate("Password changed.")
else
e.errmessage=translate("Unable to change the password.")
end
else
os.execute('passwd -l root >/dev/null')
e.message=translate("Password removed.")
end
else
e.errmessage=translate("The password and the confirmation differ.")
end
end
end
local e=Compound(a,e)
e.pageaction=false
return e
