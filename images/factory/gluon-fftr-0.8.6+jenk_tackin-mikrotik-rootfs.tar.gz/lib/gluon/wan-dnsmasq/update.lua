#!/usr/bin/lua
local n='/var/gluon/wan-dnsmasq'
local t=n..'/resolv.conf'
local h=require('ubus').connect()
local r=require('luci.model.uci').cursor()
local i=require'nixio.fs'
local e=''
local function a(t)
e=e..'nameserver '..t..'\n'
end
local function o(e)
local t=e.device
local e=e.inactive['dns-server']
for o,e in ipairs(e)do
if e:match('^fe80:')then
a(e..'%'..t)
else
a(e)
end
end
end
local function s(e)
o(h:call('network.interface.'..e,'status',{}))
end
local o=r:get_first('gluon-wan-dnsmasq','static','server')
if type(o)=='table'and#o>0 then
for t,e in ipairs(o)do
a(e)
end
else
pcall(s,'wan6')
pcall(s,'wan')
end
i.mkdirr(n)
local a=i.readfile(t)
if e~=a then
local a=io.open(t..'.tmp','w')
a:write(e)
a:close()
i.rename(t..'.tmp',t)
end
