local a=require"luci.cbi"
local i=require"luci.i18n"
local o=luci.model.uci.cursor()
local e={}
function e.section(t)
local e=o:get_bool("autoupdater","settings","enabled")
if e then
local e=t:section(a.SimpleSection,nil,
i.translate('This node will automatically update its firmware when a new version is available.'))
end
end
function e.handle(e)
return
end
return e
