local t=luci.model.uci.cursor()
local r=require'luci.util'
local h=require'gluon.sysconfig'
local n=t:get_all("network","wan")
local s=t:get_all("network","wan6")
local i=t:get_first("gluon-wan-dnsmasq","static")
local o=SimpleForm("portconfig",translate("WAN connection"))
o.template="admin/expertmode"
local a
local e
a=o:section(SimpleSection,nil,nil)
e=a:option(ListValue,"ipv4",translate("IPv4"))
e:value("dhcp",translate("Automatic (DHCP)"))
e:value("static",translate("Static"))
e:value("none",translate("Disabled"))
e.default=n.proto
e=a:option(Value,"ipv4_addr",translate("IP address"))
e:depends("ipv4","static")
e.value=n.ipaddr
e.datatype="ip4addr"
e.rmempty=false
e=a:option(Value,"ipv4_netmask",translate("Netmask"))
e:depends("ipv4","static")
e.value=n.netmask or"255.255.255.0"
e.datatype="ip4addr"
e.rmempty=false
e=a:option(Value,"ipv4_gateway",translate("Gateway"))
e:depends("ipv4","static")
e.value=n.gateway
e.datatype="ip4addr"
e.rmempty=false
a=o:section(SimpleSection,nil,nil)
e=a:option(ListValue,"ipv6",translate("IPv6"))
e:value("dhcpv6",translate("Automatic (RA/DHCPv6)"))
e:value("static",translate("Static"))
e:value("none",translate("Disabled"))
e.default=s.proto
e=a:option(Value,"ipv6_addr",translate("IP address"))
e:depends("ipv6","static")
e.value=s.ip6addr
e.datatype="ip6addr"
e.rmempty=false
e=a:option(Value,"ipv6_gateway",translate("Gateway"))
e:depends("ipv6","static")
e.value=s.ip6gw
e.datatype="ip6addr"
e.rmempty=false
if i then
a=o:section(SimpleSection,nil,nil)
e=a:option(DynamicList,"dns",translate("Static DNS servers"))
e:write(nil,t:get("gluon-wan-dnsmasq",i,"server"))
e.datatype="ipaddr"
end
a=o:section(SimpleSection,nil,nil)
e=a:option(Flag,"mesh_wan",translate("Enable meshing on the WAN interface"))
e.default=t:get_bool("network","mesh_wan","auto")and e.enabled or e.disabled
e.rmempty=false
if h.lan_ifname then
e=a:option(Flag,"mesh_lan",translate("Enable meshing on the LAN interface"))
e.default=t:get_bool("network","mesh_lan","auto")and e.enabled or e.disabled
e.rmempty=false
end
if t:get('system','gpio_switch_poe_passthrough')then
a=o:section(SimpleSection,nil,nil)
e=a:option(Flag,"poe_passthrough",translate("Enable PoE passthrough"))
e.default=t:get_bool("system","gpio_switch_poe_passthrough","value")and e.enabled or e.disabled
e.rmempty=false
end
function o.handle(o,a,e)
if a==FORM_VALID then
t:set("network","wan","proto",e.ipv4)
if e.ipv4=="static"then
t:set("network","wan","ipaddr",e.ipv4_addr:trim())
t:set("network","wan","netmask",e.ipv4_netmask:trim())
t:set("network","wan","gateway",e.ipv4_gateway:trim())
else
t:delete("network","wan","ipaddr")
t:delete("network","wan","netmask")
t:delete("network","wan","gateway")
end
t:set("network","wan6","proto",e.ipv6)
if e.ipv6=="static"then
t:set("network","wan6","ip6addr",e.ipv6_addr:trim())
t:set("network","wan6","ip6gw",e.ipv6_gateway:trim())
else
t:delete("network","wan6","ip6addr")
t:delete("network","wan6","ip6gw")
end
t:set("network","mesh_wan","auto",e.mesh_wan)
if h.lan_ifname then
t:set("network","mesh_lan","auto",e.mesh_lan)
local a
if e.mesh_lan=='1'then
a=t.remove_from_set
else
a=t.add_to_set
end
for o,e in ipairs(r.split(h.lan_ifname,' '))do
a(t,"network","client","ifname",e)
end
end
t:save("network")
t:commit("network")
if t:get('system','gpio_switch_poe_passthrough')then
t:set('system','gpio_switch_poe_passthrough','value',e.poe_passthrough)
t:save('system')
t:commit('system')
end
if i then
if#e.dns>0 then
t:set("gluon-wan-dnsmasq",i,"server",e.dns)
else
t:delete("gluon-wan-dnsmasq",i,"server")
end
t:save("gluon-wan-dnsmasq")
t:commit("gluon-wan-dnsmasq")
end
end
return true
end
return o
