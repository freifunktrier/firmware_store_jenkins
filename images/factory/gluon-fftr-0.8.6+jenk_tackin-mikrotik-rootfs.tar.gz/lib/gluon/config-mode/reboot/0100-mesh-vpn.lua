local e=luci.model.uci.cursor()
local t=e:get("fastd","mesh_vpn","enabled","0")
if t~="1"then
return nil
else
local s=require"luci.i18n"
local a=require"luci.util"
local t=require'gluon.luci'
local n=require'gluon.site_config'
local i=require'gluon.sysconfig'
local o=require'pretty_hostname'
local a=a.trim(a.exec("/etc/init.d/fastd show_key ".."mesh_vpn"))
local o=o.get(e)
local e=e:get_first("gluon-node-info","owner","contact")
local s=s.translate('gluon-config-mode:pubkey')
return function()
luci.template.render_string(s,{
pubkey=a,
hostname=o,
site=n,
sysconfig=i,
contact=e,
escape=t.escape,
urlescape=t.urlescape,
})
end
end
