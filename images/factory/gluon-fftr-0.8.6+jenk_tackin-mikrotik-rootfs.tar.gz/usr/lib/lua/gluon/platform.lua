local t=require'platform_info'
local o=require'luci.util'
local e=setmetatable
module'gluon.platform'
e(_M,
{
__index=t,
}
)
function match(t,a,e)
if get_target()~=t then
return false
end
if get_subtarget()~=a then
return false
end
if e and not o.contains(e,get_board_name())then
return false
end
return true
end
